
/*Fecha de generar reporte */
var fechaActual = new Date().toISOString().split('T')[0];
document.getElementById("fecha_inicio").value = fechaActual;
document.getElementById("fecha_fin").value = fechaActual;
