var theme = document.getElementById('icon');
var particulas = document.querySelector('#particles-js');
var form = document.querySelector('#form');
var version = document.querySelector('.version');
var overlay = document.querySelector('.overlay');
var sign = document.querySelector('.sign');
var user = document.querySelector('.user');
var admision = document.querySelector('.admision');
var button = document.querySelector('button');
var icono = document.getElementById('icon');

//Particulas de fondo
var themeState = 'dark';
// Modo dark
var particlesConfigDark = {
    fpsLimit: 60,
    particles: {
        number: {
            value: 80,
            density: {
                enable: true,
                value_area: 800
            }
        },
        color: {
            value: ["#2e7db6", "#4c7ec8", "#003296", "#36C5F0"]
        },
        shape: {
            type: "circle",
            stroke: {
                width: 0,
                color: "#fff"
            },
            polygon: {
                nb_sides: 5
            }
        },
        opacity: {
            value: 1,
            random: false,
            anim: {
                enable: true,
                speed: 1,
                opacity_min: 0.1,
                sync: false
            }
        },
        size: {
            value: 8,
            random: true,
            anim: {
                enable: true,
                speed: 1,
                size_min: 10,
                sync: false
            }
        },
        line_linked: {
            enable: true,
            distance: 150,
            color: "#808080",
            opacity: 0.4,
            width: 1
        },
        move: {
            enable: true,
            speed: 3,
            direction: "none",
            random: false,
            straight: false,
            out_mode: "out",
            bounce: false,
            attract: {
                enable: false,
                rotateX: 600,
                rotateY: 1200
            }
        }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: {
                enable: true,
                mode: "grab"
            },
            onclick: {
                enable: true,
                mode: "push"
            },
            resize: true
        },
        modes: {
            grab: {
                distance: 140,
                line_linked: {
                    opacity: 1
                }
            },
            bubble: {
                distance: 400,
                size: 40,
                duration: 2,
                opacity: 8,
                speed: 3
            },
            repulse: {
                distance: 200,
                duration: 0.4
            },
            push: {
                particles_nb: 4
            },
            remove: {
                particles_nb: 2
            }
        }
    },
    retina_detect: true
};
// Inicializar con el modo oscuro al cargar la página
particlesJS("particles-js", particlesConfigDark);
// Modo light
var particlesConfigLight = {
    fpsLimit: 60,
    particles: {
        number: {
            value: 80,
            density: {
                enable: true,
                value_area: 800
            }
        },
        color: {
            value: ["#ff0076", "#e65a5a", "#ff416c"]
        },
        shape: {
            type: "circle",
            stroke: {
                width: 0,
                color: "#fff"
            },
            polygon: {
                nb_sides: 5
            }
        },
        opacity: {
            value: 1,
            random: false,
            anim: {
                enable: true,
                speed: 1,
                opacity_min: 0.1,
                sync: false
            }
        },
        size: {
            value: 8,
            random: true,
            anim: {
                enable: true,
                speed: 1,
                size_min: 10,
                sync: false
            }
        },
        line_linked: {
            enable: true,
            distance: 150,
            color: "#353535",
            opacity: 0.4,
            width: 1
        },
        move: {
            enable: true,
            speed: 3,
            direction: "none",
            random: false,
            straight: false,
            out_mode: "out",
            bounce: false,
            attract: {
                enable: false,
                rotateX: 600,
                rotateY: 1200
            }
        }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: {
                enable: true,
                mode: "grab"
            },
            onclick: {
                enable: true,
                mode: "push"
            },
            resize: true
        },
        modes: {
            grab: {
                distance: 140,
                line_linked: {
                    opacity: 1
                }
            },
            bubble: {
                distance: 400,
                size: 40,
                duration: 2,
                opacity: 8,
                speed: 3
            },
            repulse: {
                distance: 200,
                duration: 0.4
            },
            push: {
                particles_nb: 4
            },
            remove: {
                particles_nb: 2
            }
        }
    },
    retina_detect: true
};
theme.onclick = function () {
    theme.classList.toggle('active');
    particulas.classList.toggle('active');
    form.classList.toggle('active');
    version.classList.toggle('active');
    overlay.classList.toggle('active');
    sign.classList.toggle('active');
    user.classList.toggle('active');
    admision.classList.toggle('active');
    button.classList.toggle('active');

    // Alternar entre las imágenes "sun.png" y "moon.png"
    if (icono.src.includes("sun.png")) {
        icono.src = "assets/img/theme/moon.png";
    } else {
        icono.src = "assets/img/theme/sun.png";
    }

    // Cambiar entre los modos oscuro y claro
    if (themeState === 'dark') {
        particlesJS("particles-js", particlesConfigLight); // Cambiar a modo claro
        themeState = 'light'; // Actualizar el estado del tema
    } else {
        particlesJS("particles-js", particlesConfigDark); // Cambiar a modo oscuro
        themeState = 'dark'; // Actualizar el estado del tema
    }

};

var icon2 = document.getElementById('eyes');
var claveInput = document.getElementById('clave');

icon2.onclick = function () {
    // Alternar entre las imágenes "visible.png" y "invisible.png" para mostrar las contraseñas del login
    if (claveInput.type === "password") {
        claveInput.type = "text";
        icon2.src = "assets/img/eyes/visible.png";
        icon2.alt = "Ocultar contraseña";
    } else {
        claveInput.type = "password";
        icon2.src = "assets/img/eyes/invisible.png";
        icon2.alt = "Mostrar contraseña";
    }
};
