
document.addEventListener("DOMContentLoaded", function () {
    $('#tbl').DataTable();
    $(".confirmar").submit(function (e) {
        e.preventDefault();
        Swal.fire({
            title: 'Esta seguro de eliminar?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, Eliminar!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })
    })
    
    $(".confirmarPermanente").submit(function (e) {
        e.preventDefault();
        Swal.fire({
            title: 'Esta seguro de eliminar de manera permanente?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            background: '#23272b',
                color: '#ffffff',
            confirmButtonText: 'Si, Eliminar!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })
    })


    $("#tel_cliente").autocomplete({
        minLength: 3,
        source: function (request, response) {
            $.ajax({
                url: "ajax.php",
                dataType: "json",
                data: {
                    datos_parametro: request.term
                },
                success: function (data) {
                    response(data);
                }
            });
        },
        select: function (event, ui) {
            $("#idcliente").val(ui.item.id);
            $("#tel_cliente").val(ui.item.label);
            $("#nom_cliente").val(ui.item.nombre);
            $("#dir_cliente").val(ui.item.direccion);
        }
    })


    $("#producto").autocomplete({
        minLength: 3,
        source: function (request, response) {
            $.ajax({
                url: "ajax.php",
                dataType: "json",
                data: {
                    pro: request.term
                },
                success: function (data) {
                    response(data);
                }
            });
        },
        select: function (event, ui) {
            $("#producto").val(ui.item.value);
            setTimeout(
                function () {
                    e = jQuery.Event("keypress");
                    e.which = 13;
                    registrarDetalle(e, ui.item.id, 1, ui.item.precio);
                }
            )
        }
    })
    $('#btn_generar').click(function (e) {
        e.preventDefault();
        var rows = $('#tblDetalle tr').length;
        if (rows > 2) {
            var action = 'procesarVenta';
            var id = $('#idcliente').val();
            $.ajax({
                url: 'ajax.php',
                async: true,
                data: {
                    procesarVenta: action,
                    id: id
                },
                success: function (response) {
                    const res = JSON.parse(response);
                    if (response != 'error') {
                        Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: 'Venta Generada',
                            showConfirmButton: false,
                            timer: 2000
                        })
                        setTimeout(() => {
                            generarPDF(res.id_cliente, res.id_venta);
                            location.reload();
                        }, 300);
                    } else {
                        Swal.fire({
                            position: 'top-end',
                            icon: 'error',
                            title: 'Error al generar la venta',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }
                },
                error: function (error) {

                }
            });
        }else{
            Swal.fire({
                position: 'top-end',
                icon: 'warning',
                title: 'No hay producto para generar la venta',
                showConfirmButton: false,
                timer: 2000
            })
        }
    });
    if (document.getElementById("detalle_venta")) {
        listar();
    }
})


function listar() {
    let html = '';
    let detalle = 'detalle';
    $.ajax({
        url: "ajax.php",
        dataType: "json",
        data: {
            detalle: detalle
        },
        success: function (response){
            response.forEach(row => {
                html += `<tr>
                <td>${row['id']}</td>
                <td>${row['descripcion']}</td>
                <td>${row['cantidad']}</td>
                <td>${row['precio_venta']}</td>
                <td>${row['sub_total']}</td>
                <td><button class="btn btn-danger" type="button" onclick="deleteDetalle(${row['id']})">
                <i class="fas fa-trash-alt"></i></button></td>
                </tr>`;
            });
            document.querySelector("#detalle_venta").innerHTML = html;
            calcular();
            
        }
    });
}

function registrarDetalle(e, id, cant, precio) {
    if (document.getElementById('producto').value != '') {
        if (e.which == 13) {
            if (id != null) {
                let action = 'regDetalle';
                $.ajax({
                    url: "ajax.php",
                    type: 'POST',
                    dataType: "json",
                    data: {
                        id: id,
                        cant: cant,
                        action: action,
                        precio: precio
                    },
                    success: function (response) {
                        if (response == 'registrado') {
                            Swal.fire({
                                position: 'top-end',
                                icon: 'success',
                                title: 'Producto Ingresado',
                                showConfirmButton: false,
                                timer: 2000
                            })
                            document.querySelector("#producto").value = '';
                            document.querySelector("#producto").focus();
                            listar();
                        } else if (response == 'actualizado') {
                            Swal.fire({
                                position: 'top-end',
                                icon: 'success',
                                title: 'Producto Actualizado',
                                showConfirmButton: false,
                                timer: 2000
                            })
                            document.querySelector("#producto").value = '';
                            document.querySelector("#producto").focus();
                            listar();
                        } else {
                            Swal.fire({
                                position: 'top-end',
                                icon: 'error',
                                title: 'Error al ingresar el producto',
                                showConfirmButton: false,
                                timer: 2000
                            })
                        }
                    }
                });
            }
        }
    }
}

function deleteDetalle(id) {
    let detalle = 'Eliminar'
    $.ajax({
        url: "ajax.php",
        data: {
            id: id,
            delete_detalle: detalle
        },
        success: function (response) {
            console.log(response);
            if (response == 'restado') {
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'Producto Descontado',
                    showConfirmButton: false,
                    timer: 2000
                })
                document.querySelector("#producto").value = '';
                document.querySelector("#producto").focus();
                listar();
            } else if (response == 'ok') {
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'Producto Eliminado',
                    showConfirmButton: false,
                    timer: 2000
                })
                document.querySelector("#producto").value = '';
                document.querySelector("#producto").focus();
                listar();
            } else {
                Swal.fire({
                    position: 'top-end',
                    icon: 'error',
                    title: 'Error al eliminar el producto',
                    showConfirmButton: false,
                    timer: 2000
                })
            }
        }
    });
}

function calcular() {
    // obtenemos todas las filas del tbody
    var filas = $("#tblDetalle tbody tr");

    var total = 0;

    // recorremos cada una de las filas
    filas.each(function () {

        // obtenemos las columnas de cada fila
        var columnas = $(this).find("td");

        // obtenemos el texto del importe
        var importeText = $(columnas[4]).text();

        // Utilizamos una expresión regular para extraer los números del texto
        var numeros = importeText.match(/[\d\.,]+/g);

        if (numeros && numeros.length > 0) {
            // Sumamos los valores obtenidos
            numeros.forEach(function(numero) {
                var valor = parseFloat(numero.replace(',', '.'));
                total += valor;
            });
        }
    });

    // mostramos la suma total
    var filasTotal = $("#tblDetalle tfoot tr td");
    filasTotal.eq(1).text(total.toLocaleString('es-PE', {minimumFractionDigits: 2})); // Formateamos el total con coma decimal y dos decimales
}

function generarPDF(cliente, id_venta) {
    url = 'pdf/generar.php?cl=' + cliente + '&v=' + id_venta;
    window.open(url, '_blank');
}



// Diagramas index.php
if (document.getElementById("sales-chart")) {
    const action = "sales";
    $.ajax({
        url: 'chart.php',
        type: 'POST',
        data: {
            action
        },
        async: true,
        success: function (response) {
            if (response != 0) {
                var data = JSON.parse(response);
                var nombre = [];
                var cantidad = [];
                for (var i = 0; i < data.length; i++) {
                    nombre.push(data[i]['descripcion']);
                    cantidad.push(data[i]['existencia']);
                }
                try {
                    //Sales chart
                    var ctx = document.getElementById("sales-chart");
                    if (ctx) {
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: nombre,
                                type: 'line',
                                defaultFontFamily: 'Poppins',
                                datasets: [{
                                    label: "Disponible",
                                    data: cantidad,
                                    backgroundColor: 'rgba(220, 53, 69, 0.2)',
                                    borderColor: 'rgba(220, 53, 69, 1)',
                                    borderWidth: 3,
                                    pointStyle: 'rectRounded',
                                    pointRadius: 6,
                                    pointBorderColor: 'rgba(220, 53, 69, 1)',
                                    pointBackgroundColor: '#fff',
                                    pointBorderWidth: 2
                                }, 
                                {
                                    label: "Cantidad",
                                    data: [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
                                    backgroundColor: 'rgba(40, 167, 69, 0.2)',
                                    borderColor: 'rgba(40, 167, 69, 1)',
                                    borderWidth: 3,
                                    pointStyle: 'triangle',
                                    pointRadius: 6,
                                    pointBorderColor: 'rgba(40, 167, 69, 1)',
                                    pointBackgroundColor: '#fff',
                                    pointBorderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                tooltips: {
                                    mode: 'index',
                                    titleFontSize: 12,
                                    titleFontColor: '#000',
                                    bodyFontColor: '#000',
                                    backgroundColor: '#fff',
                                    titleFontFamily: 'Poppins',
                                    bodyFontFamily: 'Poppins',
                                    cornerRadius: 3,
                                    intersect: false,
                                },
                                legend: {
                                    display: false,
                                    labels: {
                                        usePointStyle: true,
                                        fontFamily: 'Poppins',
                                    },
                                },
                                scales: {
                                    xAxes: [{
                                        display: true,
                                        gridLines: {
                                            display: false,
                                            drawBorder: false
                                        },
                                        scaleLabel: {
                                            display: false,
                                            labelString: 'Month'
                                        },
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }],
                                    yAxes: [{
                                        display: true,
                                        gridLines: {
                                            display: false,
                                            drawBorder: false
                                        },
                                        scaleLabel: {
                                            display: true,
                                            labelString: 'Cantidad',
                                            fontFamily: "Poppins"

                                        },
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }]
                                },
                                title: {
                                    display: false,
                                    text: 'Normal Legend'
                                }
                            }
                        });
                    }
                } catch (error) {
                    console.log(error);
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}

if (document.getElementById("polarChart")) {
    const action = "polarChart";
    $('.alertAddProduct').html('');
    $.ajax({
        url: 'chart.php',
        type: 'POST',
        async: true,
        data: {
            action
        },
        success: function (response) {
            if (response != 0) {
                var data = JSON.parse(response);
                var nombre = [];
                var cantidad = [];
                for (var i = 0; i < data.length; i++) {
                    nombre.push(data[i]['descripcion']);
                    cantidad.push(data[i]['cantidad']);
                }
            }
            try {

                // polar chart
                var ctx = document.getElementById("polarChart");
                if (ctx) {
                    ctx.height = 200;
                    var myChart = new Chart(ctx, {
                        type: 'polarArea',
                        data: {
                            datasets: [{
                                data: cantidad,
                                backgroundColor: [
                                    "rgb(47, 166, 213)",
                                    "rgb(62, 249, 255)",
                                    "rgb(128, 131, 253)",
                                    "rgb(35,35,35)",
                                    "rgb(11, 184, 185)",
                                    "rgb(237, 20, 61)"
                                ]

                            }],
                            labels: nombre
                        },
                        options: {
                            legend: {
                                position: 'top',
                                labels: {
                                    fontFamily: 'Poppins'
                                }

                            },
                            responsive: true
                        }
                    });
                }

            } catch (error) {
                console.log(error);
            }
        },
        error: function (error) {
            console.log(error);

        }
    });
}


if (document.getElementById("sales-chart2")) {
    const action = "sales2";
    $.ajax({
        url: 'chart.php',
        type: 'POST',
        data: { action },
        async: true,
        success: function (response) {
            if (response != 0) {
                var data = JSON.parse(response);
                var nombre = [];
                var fecha = [];
                var cantidad = [];
                for (var i = 0; i < data.length; i++) {
                    nombre.push(data[i]['nombre_cliente']);
                    fecha.push(data[i]['id']);
                    cantidad.push(data[i]['total']);
                }
                try {
                    //Sales chart
                    var ctx = document.getElementById("sales-chart2");
                    if (ctx) {
                        ctx.height = 200;
                        var myChart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: nombre,
                                datasets: [{
                                    label: "Id Venta",
                                    data: fecha,
                                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                    borderColor: 'rgba(255, 99, 132, 1)',
                                    borderWidth: 1
                                }, {
                                    label: "Pago Total",
                                    data: cantidad,
                                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                    borderColor: 'rgba(54, 162, 235, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                responsive: true,
                                legend: {
                                    display: true
                                },
                                scales: {
                                    xAxes: [{
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }],
                                    yAxes: [{
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }]
                                }
                            }
                        });
                    }
                } catch (error) {
                    console.log(error);
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}


if (document.getElementById("sales-chart3")) {
    const action = "sales3";
    $.ajax({
        url: 'chart.php',
        type: 'POST',
        data: {
            action
        },
        async: true,
        success: function (response) {
            if (response != 0) {
                var data = JSON.parse(response);
                var nombre = [];
                var cantidad = [];
                for (var i = 0; i < data.length; i++) {
                    nombre.push(data[i]['descripcion']);
                    cantidad.push(data[i]['existencia']);
                }
                try {
                    //Sales chart
                    var ctx = document.getElementById("sales-chart3");
                    if (ctx) {
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: nombre,
                                type: 'line',
                                defaultFontFamily: 'Poppins',
                                datasets: [{
                                    label: "Disponible",
                                    data: cantidad,
                                    backgroundColor: 'transparent',
                                    borderColor: 'rgba(220,53,69,0.75)',
                                    borderWidth: 3,
                                    pointStyle: 'circle',
                                    pointRadius: 5,
                                    pointBorderColor: 'transparent',
                                    pointBackgroundColor: 'rgba(220,53,69,0.75)',
                                }, {
                                    label: "Cantidad",
                                    data: [0, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                                    backgroundColor: 'transparent',
                                    borderColor: 'rgba(40,167,69,0.75)',
                                    borderWidth: 3,
                                    pointStyle: 'circle',
                                    pointRadius: 5,
                                    pointBorderColor: 'transparent',
                                    pointBackgroundColor: 'rgba(40,167,69,0.75)',
                                }]
                            },
                            options: {
                                responsive: true,
                                tooltips: {
                                    mode: 'index',
                                    titleFontSize: 12,
                                    titleFontColor: '#000',
                                    bodyFontColor: '#000',
                                    backgroundColor: '#fff',
                                    titleFontFamily: 'Poppins',
                                    bodyFontFamily: 'Poppins',
                                    cornerRadius: 3,
                                    intersect: false,
                                },
                                legend: {
                                    display: false,
                                    labels: {
                                        usePointStyle: true,
                                        fontFamily: 'Poppins',
                                    },
                                },
                                scales: {
                                    xAxes: [{
                                        display: true,
                                        gridLines: {
                                            display: false,
                                            drawBorder: false
                                        },
                                        scaleLabel: {
                                            display: false,
                                            labelString: 'Month'
                                        },
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }],
                                    yAxes: [{
                                        display: true,
                                        gridLines: {
                                            display: false,
                                            drawBorder: false
                                        },
                                        scaleLabel: {
                                            display: true,
                                            labelString: 'Cantidad',
                                            fontFamily: "Poppins"

                                        },
                                        ticks: {
                                            fontFamily: "Poppins"
                                        }
                                    }]
                                },
                                title: {
                                    display: false,
                                    text: 'Normal Legend'
                                }
                            }
                        });
                    }
                } catch (error) {
                    console.log(error);
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}



/* Cambiar la contraseña de usuario en perfil - footer.php*/

function btnCambiar(e) {
    e.preventDefault();
    const actual = document.getElementById('actual').value;
    const nueva = document.getElementById('nueva').value;
    const confirmar = document.getElementById('confirmar').value;

    if (actual == "" || nueva == "" || confirmar == "") {
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: 'Los campos están vacíos',
            showConfirmButton: false,
            timer: 2000
        });
    } else if (nueva !== confirmar) {
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: 'Las nuevas contraseñas no coinciden',
            showConfirmButton: false,
            timer: 2000
        });
    } else {
        const cambio = 'pass';
        $.ajax({
            url: "ajax.php",
            type: 'POST',
            data: {
                actual: actual,
                nueva: nueva,
                cambio: cambio
            },
            success: function (response) {
                console.log(response);
                if (response == 'ok') {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Contraseña modificada',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    document.getElementById('actual').value = "";
                    document.getElementById('nueva').value = "";
                    document.getElementById('confirmar').value = "";
                    $("#nuevo_pass").modal("hide");
                } else if (response == 'dif') {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'error',
                        title: 'La contraseña actual es incorrecta',
                        showConfirmButton: false,
                        timer: 2000
                    });
                } else {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'error',
                        title: 'Error al modificar la contraseña',
                        showConfirmButton: false,
                        timer: 2000
                    });
                }
            }
        });
    }
}



/* Permite ver la contraseña de usuario en perfil - footer.php*/

var icon1 = document.getElementById('eyes1');
var claveInput1 = document.getElementById('actual');
icon1.onclick = function () {
    if (claveInput1.type === "password") {
        claveInput1.type = "text";
        icon1.src = "../assets/img/eyes/visible.png";
        icon1.alt = "Ocultar contraseña";
    } else {
        claveInput1.type = "password";
        icon1.src = "../assets/img/eyes/invisible.png";
        icon1.alt = "Mostrar contraseña";
    }
};

var icon2 = document.getElementById('eyes2');
var claveInput2 = document.getElementById('nueva');
icon2.onclick = function () {
    if (claveInput2.type === "password") {
        claveInput2.type = "text";
        icon2.src = "../assets/img/eyes/visible.png";
        icon2.alt = "Ocultar contraseña";
    } else {
        claveInput2.type = "password";
        icon2.src = "../assets/img/eyes/invisible.png";
        icon2.alt = "Mostrar contraseña";
    }
};

var icon3 = document.getElementById('eyes3');
var claveInput3 = document.getElementById('confirmar');
icon3.onclick = function () {
    if (claveInput3.type === "password") {
        claveInput3.type = "text";
        icon3.src = "../assets/img/eyes/visible.png";
        icon3.alt = "Ocultar contraseña";
    } else {
        claveInput3.type = "password";
        icon3.src = "../assets/img/eyes/invisible.png";
        icon3.alt = "Mostrar contraseña";
    }
};

/* Permite ver la ingresar la contraseña actual de editar de usuario- editar usuario.php*/
var icon4 = document.getElementById('eyes4');
var claveInput4 = document.getElementById('clave');
icon4.onclick = function () {
    if (claveInput4.type === "password") {
        claveInput4.type = "text";
        icon4.src = "../assets/img/eyes/visible.png";
        icon4.alt = "Ocultar contraseña";
    } else {
        claveInput4.type = "password";
        icon4.src = "../assets/img/eyes/invisible.png";
        icon4.alt = "Mostrar contraseña";
    }
};

/* Habilita el desplazamiento vertical de nombre del cliente - venta.php*/
window.addEventListener('DOMContentLoaded', function() {
    var scrollableContent = document.getElementById('scrollableContent');
    var contentHeight = scrollableContent.scrollHeight;

    if (contentHeight > 300) {
        scrollableContent.classList.add('scrollable');
    } else {
        scrollableContent.classList.remove('scrollable');
    }
});