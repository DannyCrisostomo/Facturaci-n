<?php
session_start();
if (!empty($_SESSION['active'])) {
    header('location: src/');
} else {
    if (!empty($_POST)) {
        $alert = '';
        if (empty($_POST['correo']) || empty($_POST['clave'])) {
            $alert = '<div class="alert alert-danger" role="alert">
            Ingrese su correo y su clave
            </div>';
        } else {
            require_once "conexion.php";
            $user = mysqli_real_escape_string($conexion, $_POST['correo']);
            $clave = md5(mysqli_real_escape_string($conexion, $_POST['clave']));
            $query = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo = '$user' AND clave = '$clave' AND estado = 1");
            mysqli_close($conexion);
            $resultado = mysqli_num_rows($query);
            if ($resultado > 0) {
                $dato = mysqli_fetch_array($query);
                $_SESSION['active'] = true;
                $_SESSION['idUser'] = $dato['idusuario'];
                $_SESSION['nombre'] = $dato['nombre'];
                $_SESSION['user'] = $dato['correo'];
                // Verifica si el tema ya está establecido en el almacenamiento local
                // Si no lo está, establece el tema predeterminado
                if (!isset($_SESSION['theme'])) {
                    $_SESSION['theme'] = 'claro'; // Tema predeterminado
                }
                header('location: src/');
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                Usuario o Contraseña Incorrecta
                </div>';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel='icon' type='image/png' sizes='32x32' href='assets/img/icono1.png'>
	<link rel='icon' type='image/png' sizes='32x32' href='assets/img/icono2.png'>
	<link rel="stylesheet" href="assets/css/login.css">
	<link rel="stylesheet" href="assets/css/login-active.css">
	<title>PAGOS-FACTURAS</title>
</head>

<body>
	<div id="particles-js"></div>

	<div class="icon-container">
		<img id="icon" class="light" src="assets/img/theme/sun.png" alt="">
	</div>

	<div class="start-container">
		<div class="container" id="container">
			<div class="form-container sign-up-container">
				<form action="#">
					<h3 class="sign-fingerprint">Iniciar Sesión con Huella</h3>
					<span class="sensor">Toca el sensor de huella dactilar</span>
					<img class="sign-fingerprint-blue" src="assets/img/huellaAzul.png" border="0">
				</form>
			</div>
			<div class="form-container sign-in-container">

				<form id="form" action="" method="POST">
					<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="transparent">
						<tr>
							<td align="center" width="1%">
								<img height='50px' class="admision" src="assets/img/admision.png" border="0">
								<h2 class="version">v 1.0.00</h2>
							</td>
						</tr>
						<tr>
							<td>
								<h3 class="sign">Iniciar Sesión</h3>

								<span class="user">Ingrese su usuario y contraseña</span>
								</br></br>

								<input type="email" id="correo" name="correo" placeholder="Correo" />

								<div class="password-eyes">
									<input type="password" id="clave" name="clave" placeholder="Contraseña" />
									<img class="eyes" id="eyes" src="assets/img/eyes/invisible.png" alt="Mostrar contraseña">
								</div>

								</br></br>
								<button type="submit" onclick="resetStorage()">Iniciar Sesion</button>
							</td>
						</tr>
					</table>
				</form>

			</div>
			<div class="overlay-container">
				<div class="overlay">
					<div class="overlay-panel overlay-right">
						<h2 class="payments">PAGOS - FACTURAS</h2>
						<p>Ingrese utilizando su huella dactilar</p>
						<img class="sign-fingerprint-white " src="assets/img/huellaBlanco.png" border="0">
						<em class="sensor-fingerprint">Toca el sensor de huella dactilar</em>
					</div>
				</div>
			</div>
		</div>
	</div>


	<script src="assets/js/particula.js"></script>
	<script src="assets/js/login.active.js"></script>
	<script src="assets/js/ParticulaPersonalizada.js"></script>
</body>

</html>