<?php
include_once "includes/header.php";
require_once "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "configuracion";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

$query = mysqli_query($conexion, "SELECT * FROM configuracion");
$data = mysqli_fetch_assoc($query);

// Verificar si se ha enviado el formulario
if (!empty($_POST)) {
    // Procesar la actualización de datos
    if (
        empty($_POST['nombre']) || empty($_POST['telefono']) ||
        empty($_POST['email']) || empty($_POST['direccion']) ||
        empty($_POST['ubicacion']) || empty($_POST['Provincia']) || empty($_POST['link'])
    ) {
        $_SESSION['alert'] = '<div class="alert alert-danger" role="alert">Todos los campos son requeridos</div>';
    } else {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $email = $_POST['email'];
        $direccion = $_POST['direccion'];
        $provincia = $_POST['Provincia'];
        $ubicacion = $_POST['ubicacion'];
        $link = $_POST['link'];
        $sql_update = mysqli_query($conexion, "UPDATE configuracion SET nombre = '$nombre', telefono = '$telefono', email = '$email', direccion = '$direccion', ubicacion = '$ubicacion', Provincia = '$provincia', link= '$link'  WHERE id = $id");
        
        if ($sql_update) {
            $_SESSION['alert'] = '<div class="alert alert-success" role="alert">Datos de la empresa Actualizados</div>';
            
            echo '<meta http-equiv="refresh" content="0">';
            exit(); 
        } else {
            $_SESSION['alert'] = '<div class="alert alert-danger" role="alert">Error al Actualizar a la empresa</div>';
            echo '<meta http-equiv="refresh" content="0">';
            exit();
        }
    }
}
?>


<main id="configuracion">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Datos de la Empresa - Generar PDF
                </div>
                <div class="card-body">
                    <form action="" method="post" class="p-3">
                        <?php
                        if (isset($_SESSION['alert'])) {
                            echo $_SESSION['alert'];
                            unset($_SESSION['alert']); // Limpiar la variable de sesión después de mostrar el mensaje
                        }
                        ?>

                        <div class="form-group">
                            <label><i class="fas fa-building"></i> Nombre:</label>
                            <input type="hidden" name="id" value="<?php echo $data['id'] ?>">
                            <input type="text" name="nombre" class="form-control" value="<?php echo $data['nombre']; ?>"
                                id="txtNombre" placeholder="Nombre de la Empresa" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-map-marked-alt"></i> Direccion:</label>
                            <input type="text" name="ubicacion" class="form-control"
                                value="<?php echo $data['ubicacion']; ?>" id="txtUbicacion"
                                placeholder="Ubicacion de la Empresa" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-map-marked-alt"></i> Provincia:</label>
                            <input type="text" name="Provincia" class="form-control"
                                value="<?php echo $data['Provincia']; ?>" id="txtProvincia"
                                placeholder="Provincia de la Empresa" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> RUC:</label>
                            <input type="number" name="direccion" class="form-control"
                                value="<?php echo $data['direccion']; ?>" placeholder="Ruc de la Empresa" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-mobile"></i> Teléfono:</label>
                            <input type="text" name="telefono" class="form-control"
                                value="<?php echo $data['telefono']; ?>" id="txtTelEmpresa"
                                placeholder="teléfono de la Empresa" required>
                        </div>

                        <div class="form-group">
                            <label> <i class="fas fa-envelope"></i> Correo Electrónico:</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $data['email']; ?>"
                                id="txtEmailEmpresa" placeholder="Correo de la Empresa" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-link"></i> Link:</label>
                            <input type="text" name="link" class="form-control" value="<?php echo $data['link']; ?>"
                                id="txtLink" placeholder="Provincia de la Empresa" required>
                        </div>



                        <div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Modificar
                                Datos</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include_once "includes/footer.php"; ?>