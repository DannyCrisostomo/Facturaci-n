<?php
include_once "includes/header.php";
require_once "../conexion.php";

// Función para generar el código de venta
function generarCodigoVenta($numero_actual)
{
    // Formatear el nuevo número con ceros a la izquierda
    $nuevo_numero_formateado = str_pad($numero_actual, 8, '0', STR_PAD_LEFT);
    // Construir el nuevo código de venta
    $nuevo_codigo = 'B146-' . $nuevo_numero_formateado;
    return $nuevo_codigo;
}

$id_user = $_SESSION['idUser'];
$permiso = "ventas";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

$query = mysqli_query($conexion, "SELECT v.*, c.idcliente, c.nombre FROM ventas v INNER JOIN cliente c ON v.id_cliente = c.idcliente");

// Determinar el último código de venta generado
$ultimo_codigo_query = mysqli_query($conexion, "SELECT MAX(SUBSTRING_INDEX(codigo_venta, '-', -1)) AS ultimo_codigo FROM ventas");
$ultimo_codigo_resultado = mysqli_fetch_assoc($ultimo_codigo_query);
$ultimo_codigo_generado = intval($ultimo_codigo_resultado['ultimo_codigo']);

// Actualizar los códigos de venta en la base de datos
while ($row = mysqli_fetch_assoc($query)) {
    // Solo actualizar el código de venta si aún no ha sido generado
    if (empty($row['codigo_venta'])) {
        $ultimo_codigo_generado++; // Incrementar el contador para el siguiente código
        $codigo_venta = generarCodigoVenta($ultimo_codigo_generado);
        // Insertar el código de venta en la base de datos
        $id_venta = $row['id'];
        mysqli_query($conexion, "UPDATE ventas SET codigo_venta = '$codigo_venta' WHERE id = $id_venta");
    }
}

// Consultar nuevamente las ventas con los códigos de venta actualizados
$query = mysqli_query($conexion, "SELECT v.*, c.idcliente, c.nombre FROM ventas v INNER JOIN cliente c ON v.id_cliente = c.idcliente");

?>

<form action="Generadores/ventasCSV.php" method="post">
    <div class="row" style="padding: 20px 0 20px; display: flex; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div class="col-md-2">
            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control form-control-sm"
                aria-controls="tbl">
        </div>
        <div class="col-md-2">
            <input type="date" name="fecha_fin" id="fecha_fin" class="form-control form-control-sm" aria-controls="tbl">
        </div>
        <div class="col-md-2">
            <input type="submit" name="btnGenerarReporte" value="Generar Reporte CSV" class="btn btn-success btn-md">
        </div>
    </div>
</form>


<table class="table table-light" id="tbl">
    <thead class="thead-dark">
        <tr>
            <th><i class="fas fa-shopping-cart"></i> ID</th>
            <th><i class="fas fa-user"></i> Cliente</th>
            <th><i class="fas fa-barcode"></i> Código de Venta</th>
            <th><i class="far fa-calendar-alt"></i> Fecha</th>
            <th><i class="fas fa-dollar-sign"></i> Pago Total</th>
            <th><i class="fas fa-file-pdf"></i> Facturas </i></th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = mysqli_fetch_assoc($query)) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['nombre']; ?></td>
                <td><?php echo $row['codigo_venta']; ?></td>
                <td><?php echo $row['fecha']; ?></td>
                <td><?php echo $row['total']; ?></td>
                <td>
                    <a href="pdf/generar.php?cl=<?php echo $row['id_cliente'] ?>&v=<?php echo $row['id'] ?>" target="_blank"
                        class="btn btn-danger"><i class="fas fa-file-pdf"></i></a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<script src="../assets/js/fechas.js"></script>

<?php include_once "includes/footer.php"; ?>