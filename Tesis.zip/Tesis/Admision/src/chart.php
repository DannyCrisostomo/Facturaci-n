<?php
include ("../conexion.php");


if ($_POST['action'] == 'sales') {
    $arreglo = array();
    $query = mysqli_query($conexion, "SELECT descripcion, existencia FROM producto WHERE existencia <= 10 ORDER BY existencia ASC LIMIT 10");
    while ($data = mysqli_fetch_array($query)) {
        $arreglo[] = $data;
    }
    echo json_encode($arreglo);
    die();
}

if ($_POST['action'] == 'sales2') {
    $arreglo = array();
    
    $query = mysqli_query($conexion, "SELECT v.id, v.total, c.nombre AS nombre_cliente 
    FROM ventas v 
    INNER JOIN cliente c ON v.id_cliente = c.idcliente  
    WHERE v.id_cliente <= 1000000 
    ORDER BY v.fecha DESC 
    LIMIT 3;
    
    ");

    while ($data = mysqli_fetch_array($query)) {
        $arreglo[] = $data;
    }
    echo json_encode($arreglo);
    die();
}

if ($_POST['action'] == 'polarChart') {
    $arreglo = array();
    $query = mysqli_query($conexion, "SELECT p.codproducto, p.descripcion, d.id_producto, d.cantidad, SUM(d.cantidad) as total FROM producto p INNER JOIN detalle_venta d WHERE p.codproducto = d.id_producto group by d.id_producto ORDER BY d.cantidad DESC LIMIT 6");
    while ($data = mysqli_fetch_array($query)) {
        $arreglo[] = $data;
    }
    echo json_encode($arreglo);
    die();
}

if ($_POST['action'] == 'sales3') {
    $arreglo = array();
    $query = mysqli_query($conexion, "SELECT * FROM usuario ");
    while ($data = mysqli_fetch_array($query)) {
        $arreglo[] = $data;
    }
    echo json_encode($arreglo);
    die();
}


?>

