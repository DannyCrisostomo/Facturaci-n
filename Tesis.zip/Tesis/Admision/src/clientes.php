<?php
include_once "includes/header.php";
include "../conexion.php";

// Verificar permisos
$id_user = $_SESSION['idUser'];
$permiso = "clientes";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
    exit; // Salir del script después de redireccionar
}

// Procesar formulario de nuevo cliente
if (isset($_POST['nombre']) || isset($_POST['telefono']) || isset($_POST['direccion'])) {
    $alert = "";
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';
    $telefono = isset($_POST['telefono']) ? $_POST['telefono'] : '';
    $direccion = isset($_POST['direccion']) ? $_POST['direccion'] : '';

    // Validar datos de entrada
    if (empty($nombre) || empty($telefono) || empty($direccion)) {
        $alert = '<div class="alert alert-danger" role="alert">Todos los campos son obligatorios</div>';
    } else {
        $nombre = mysqli_real_escape_string($conexion, $nombre); // Evitar inyección de SQL

        // Verificar si el cliente ya existe
        $query = mysqli_query($conexion, "SELECT * FROM cliente WHERE nombre = '$nombre'");
        if (mysqli_num_rows($query) > 0) {
            $alert = '<div class="alert alert-danger" role="alert">El cliente ya existe</div>';
        } else {
            // Insertar nuevo cliente
            $query_insert = mysqli_query($conexion, "INSERT INTO cliente(nombre,telefono,direccion, usuario_id) values ('$nombre', '$telefono', '$direccion', '$id_user')");
            if ($query_insert) {
                $alert = '<div class="alert alert-success" role="alert">Cliente registrado</div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">Error al registrar</div>';
            }
        }
    }
}

// Definir el número de registros por página basado en el parámetro del formulario o un valor predeterminado
$registros_por_pagina = isset($_POST['registros_por_pagina']) ? $_POST['registros_por_pagina'] : 10; 

// Restricción para evitar que se muestren demasiados registros
if ($registros_por_pagina != 30 && $registros_por_pagina != 25 && $registros_por_pagina != 50 && $registros_por_pagina != 100) {
    $registros_por_pagina = 10;
}

// Determinar la página actual
$pagina_actual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

// Calcular el offset para la consulta SQL
$offset = ($pagina_actual - 1) * $registros_por_pagina;

// Consulta SQL para obtener el total de registros
$total_query = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM cliente");
$total_registros = mysqli_fetch_assoc($total_query)['total'];

// Calcular el número total de páginas
$total_paginas = ceil($total_registros / $registros_por_pagina);

// Consulta SQL con paginación basada en el nuevo número de registros por página
$query = mysqli_query($conexion, "SELECT * FROM cliente LIMIT $offset, $registros_por_pagina");

// Incluir HTML para mostrar los resultados
include_once "includes/header.php";
?>
<button class="btn btn-primary mb-2" type="button" data-toggle="modal" data-target="#nuevo_cliente"><i
        class="fas fa-plus"></i></button>
<?php echo isset($alert) ? $alert : ''; ?>
<div class="table-responsive">


<table class="table table-striped table-bordered" >
        <div class="dataTables_length">
            <label class="mostrar-cliente">Mostrando  
                <form method="POST" action="clientes.php">
                    <select class="custom-select custom-select-sm" name="registros_por_pagina"
                        onchange="this.form.submit()">
                        <option value="10" <?php if ($registros_por_pagina == 10)
                            echo 'selected'; ?>>10</option>
                        <option value="25" <?php if ($registros_por_pagina == 25)
                            echo 'selected'; ?>>25</option>
                        <option value="50" <?php if ($registros_por_pagina == 50)
                            echo 'selected'; ?>>50</option>
                        <option value="100" <?php if ($registros_por_pagina == 100)
                            echo 'selected'; ?>>100</option>
                    </select>
                </form> 
                 Entradas.
            </label>

           

        </div>

        <thead class="thead-dark">
            <tr>
                <th><i class="fas fa-id-badge"></i> ID</th>
                <th><i class="fas fa-user"></i> Nombre Completo</th>
                <th><i class="fas fa-address-card"></i> DNI</th>
                <th><i class="fas fa-map-marker-alt"></i> Dirección</th>
                <th><i class="fas fa-toggle-on"></i> Estado</th>
                <th><i class="fas fa-cogs"></i> Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($query) > 0) {
                while ($data = mysqli_fetch_assoc($query)) {
                    $estado = ($data['estado'] == 1) ? '<span class="badge badge-pill badge-success">Activo</span>' : '<span class="badge badge-pill badge-danger">Inactivo</span>';
                    ?>
                    <tr>
                        <td><?php echo $data['idcliente']; ?></td>
                        <td><?php echo $data['nombre']; ?></td>
                        <td><?php echo $data['telefono']; ?></td>
                        <td><?php echo $data['direccion']; ?></td>
                        <td><?php echo $estado; ?></td>
                        <td>
                            <?php if ($data['estado'] == 1) { ?>
                                <a href="editar_cliente.php?id=<?php echo $data['idcliente']; ?>&pagina=<?php echo $pagina_actual; ?>"
                                    class="btn btn-success"><i class='fas fa-edit'></i></a>
                                <form
                                    action="eliminar_cliente.php?id=<?php echo $data['idcliente']; ?>&pagina=<?php echo $pagina_actual; ?>"
                                    method="post" class="confirmar d-inline">
                                    <button class="btn btn-danger" type="submit"><i class='fas fa-trash-alt'></i> </button>
                                </form>
                            <?php } else { ?>
                                <a href="activar_cliente.php?id=<?php echo $data['idcliente']; ?>&pagina=<?php echo $pagina_actual; ?>"
                                    class="btn btn-warning"><i class='fas fa-lock'></i></a>
                                <form
                                    action="☺elimar_permanente_cliente.php?id=<?php echo $data['idcliente']; ?>&pagina=<?php echo $pagina_actual; ?>"
                                    method="post" class="confirmarPermanente d-inline">
                                    <button class="btn btn-dark" type="submit"><i class='fas fa-skull'></i> </button>
                                </form>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='6'>No se encontraron resultados.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<!-- Agregar enlaces de paginación -->
<nav aria-label="Paginación">
    <ul class="pagination justify-content-center">
        <?php if ($pagina_actual > 1): ?>
            <li class="page-item"><a class="page-link"
                    href="clientes.php?pagina=<?php echo $pagina_actual - 1; ?>&registros_por_pagina=<?php echo $registros_por_pagina; ?>">Anterior</a>
            </li>
        <?php endif; ?>
        <?php if ($pagina_actual > 3): ?>
            <li class="page-item"><a class="page-link"
                    href="clientes.php?pagina=1&registros_por_pagina=<?php echo $registros_por_pagina; ?>">1</a></li>
            <li class="page-item disabled"><span class="page-link">...</span></li>
        <?php endif; ?>
        <?php for ($i = max(1, $pagina_actual - 2); $i <= min($total_paginas, $pagina_actual + 2); $i++): ?>
            <li class="page-item <?php echo ($pagina_actual == $i) ? 'active' : ''; ?>"><a class="page-link"
                    href="clientes.php?pagina=<?php echo $i; ?>&registros_por_pagina=<?php echo $registros_por_pagina; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>
        <?php if ($pagina_actual < $total_paginas - 2): ?>
            <li class="page-item disabled"><span class="page-link">...</span></li>
            <li class="page-item"><a class="page-link"
                    href="clientes.php?pagina=<?php echo $total_paginas; ?>&registros_por_pagina=<?php echo $registros_por_pagina; ?>"><?php echo $total_paginas; ?></a>
            </li>
        <?php endif; ?>
        <?php if ($pagina_actual < $total_paginas): ?>
            <li class="page-item"><a class="page-link"
                    href="clientes.php?pagina=<?php echo $pagina_actual + 1; ?>&registros_por_pagina=<?php echo $registros_por_pagina; ?>">Siguiente</a>
            </li>
        <?php endif; ?>
    </ul>
    <label class="mostrar-cliente">Mostrando <?php echo ($offset + 1) . " a " . min($offset + $registros_por_pagina, $total_registros); ?> de <?php echo $total_registros; ?> entradas.

</nav>


<!-- Modal Nuevo Cliente -->
<div id="nuevo_cliente" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="my-modal-title">Nuevo Cliente</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <div class="form-group">
                        <label for="nombre"><i class="fas fa-user"></i> Nombre Completo</label>
                        <input type="text" placeholder="Ejemplo: María García Pérez" name="nombre" id="nombre"
                            class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="telefono"><i class="fas fa-address-card"></i> DNI</label>
                        <input type="number" placeholder="Ejemplo: 87356547" name="telefono" id="telefono"
                            class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="direccion"><i class="fas fa-map-marker-alt"></i> Dirección</label>
                        <input type="text" placeholder="Ejemplo:  Calle 123, Santa Ana" name="direccion" id="direccion"
                            class="form-control">
                    </div>
                    <input type="submit" value="Guardar Cliente" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once "includes/footer.php"; ?>