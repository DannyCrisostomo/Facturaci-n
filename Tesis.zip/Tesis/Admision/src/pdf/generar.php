<?php
require_once '../../conexion.php';
require_once 'fpdf/fpdf.php';
require_once 'numero a texto.php';


// Crear el objeto FPDF sin especificar un tamaño de página inicial
$pdf = new FPDF('P', 'mm', array(80, 150));   //$pdf = new FPDF('P', 'mm', array(800, 150)); cambiar para ver la columna


// Calcular la altura total del contenido
$altura_total = 0; // Calcula la altura total de tu contenido aquí

// Establecer la altura del documento según la altura del contenido
$pdf->SetAutoPageBreak(true, $altura_total > 10000);

$pdf->AddPage(); // Añadir una nueva página automáticamente
$pdf->SetMargins(4, 0, 4);
$pdf->SetTitle("Boleta");
$pdf->SetFont('Arial', 'B', 12);














$id = $_GET['v'];
$idcliente = $_GET['cl'];


$config = mysqli_query($conexion, "SELECT * FROM configuracion");
$datos = mysqli_fetch_assoc($config);

$clientes = mysqli_query($conexion, "SELECT * FROM cliente WHERE idcliente = $idcliente");
$datosC = mysqli_fetch_assoc($clientes);







$Fechas = mysqli_query($conexion, "SELECT * FROM ventas  ");
$datosF = mysqli_fetch_assoc($Fechas);








$ventas = mysqli_query($conexion, "SELECT d.*, p.codigo, p.descripcion FROM 
detalle_venta d INNER JOIN producto p 
ON d.id_producto = p.codproducto 
WHERE d.id_venta = $id");


// Ahora, agregamos el contenido a la página
$altura_total = 0; // Altura total del contenido en la página
$altura_maxima = 150; // Altura máxima de la página (en mm)




//RED DE SALUD CHANCHAMAYO
$tamaño_fuente = 8; // Definir el tamaño de la fuente
$ancho_celda = 68; // Definir el ancho de la celda
$pdf->SetFont('arial', 'B', $tamaño_fuente); // Establecer la fuente como negrita
$pdf->SetY($pdf->GetY() - 4.5); // Mover hacia arriba 4.5 unidades
$pdf->Cell($ancho_celda, 5, utf8_decode($datos['nombre']), 0, 1, 'C');

//JR. TARMA N° 140
$pdf->SetFont('Arial', '', 7);
$pdf->Cell(67, 3, utf8_decode($datos['ubicacion']), 100, 5, 'C');

//CHANCHAMAYO - CHANCHAMAYO - JUNIN
$pdf->SetFont('Arial', '', 7);
$pdf->Cell(67, 3, utf8_decode($datos['Provincia']), 100, 5, 'C');

//BOLETA DE VENTA ELECTRONICA
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(67, 8, utf8_decode("BOLETA DE VENTA ELECTRONICA"), 100, 5, 'C');

//direccion
$pdf->SetFont('Arial', 'B', 7.5);
$pdf->Cell(66, 1, utf8_decode("RUC: " . $datos['direccion']), 0, 1, 'C');

//codigo_venta
$pdf->SetFont('Arial', 'B', 7.5);
$pdf->Cell(67, 11, utf8_decode($datosF['codigo_venta']), 0, 1, 'C');

//primera linea
$pdf->SetFont('Arial', 'B', 13);
$pdf->SetY($pdf->GetY() - 2); 
$pdf->Cell(68.5, .1, "", 1, 1, 'C', 1);

//Fecha de emisión
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(25, 5, utf8_decode("Fecha de emisión "), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 8.2);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(30, 5, utf8_decode($datosF['fecha']), 0, 1, 'C');

//Señor(es)
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(15, 3, utf8_decode("Señor(es) "), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 7);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(51, 3, utf8_decode($datosC['nombre']), 0, 1, 'C');

//Señor(es) DNI
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(7, 6, utf8_decode("DNI "), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 8.2);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(52, 6, utf8_decode($datosC['telefono']), 0, 1, 'C');

//Domicilio
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(13, 2, utf8_decode("Domicilio"), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 8.2);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(32, 2, utf8_decode($datosC['direccion']), 0, 1, 'C');


$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(12, 6, utf8_decode("Teléfono"), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 8.2);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(45, 6, utf8_decode($datos['telefono']), 0, 1, 'C');


//Establecimiento del emisor
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(26, 2, utf8_decode("Establecimiento del"), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 6);
$pdf->Cell(1, 0, '', 0, 0); 
$pdf->Cell(32, 2, utf8_decode("C.S. VILLA PERENE: JIRÓN JR"), 0, 1, 'C');

$tamaño_fuente = 6; 
$UCAYALI = 90.5; 
$DISTRITO = 86.3; 
$CHANCHAMAYO = 90.3; 
$JUNIN = 61;
$pdf->SetFont('arial', 'B', $tamaño_fuente); 
$pdf->SetY($pdf->GetY() - 1); 
$pdf->Cell($UCAYALI, 5, utf8_decode("UCAYALI MZ K SEGUNDA MESETA"), 0, 1, 'C');
$pdf->Cell($DISTRITO, 0, utf8_decode("DISTRITO PERENE PROVINCIA"), 0, 2, 'C');
$pdf->Cell($CHANCHAMAYO, 5, utf8_decode("CHANCHAMAYO DEPARTAMENTO"), 0, 3, 'C');
$pdf->Cell($JUNIN, 0, utf8_decode("JUNIN"), 0, 4, 'C');

$tamaño_fuente = 8; 
$ancho_celda = 10; 
$pdf->SetFont('arial', '', $tamaño_fuente); 
$pdf->SetY($pdf->GetY() - 10); 
$pdf->Cell($ancho_celda, 6, utf8_decode("emisor"), 0, 1, 'C');

//Tipo de Moneda
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(21.5, 16.5, utf8_decode("Tipo de Moneda"), 0, 0, 'C');
$pdf->SetFont('Arial', 'B', 7.5);
$pdf->Cell(1, 1, '', 0, 0); 
$pdf->Cell(16.5, 16.5, utf8_decode("Soles"), 0, 1, 'C');

//Observaciones
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(20.5, -8, utf8_decode("Observaciones"), 0, 0, 'C');

//Primera linea compras
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(30, 0, utf8_decode(" _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "), 0, 0, 'C');

// Configuración de la fuente
$pdf->SetFont('Arial', '', 7);
// Encabezados de la tabla
$pdf->Cell(-86, 8, utf8_decode('Codigo'), 0, 0, 'C');
$pdf->Cell(108, 8, 'Cant', 0, 0, 'C');
$pdf->Cell(-83, 8, utf8_decode('Descripción'), 0, 0, 'C');
$pdf->Cell(149, 8, 'Sub Total', 0, 0, 'C');      //$pdf->Cell(123, 8, 'Precio', 0, 0, 'C'); 
$pdf->Cell(-99, 8, 'Precio', 0, 1, 'C');  //$pdf->Cell(-99, 8, 'Sub Total', 0, 1, 'C');

//Segunda linea compras
$pdf->SetY($pdf->GetY() -6); 
$pdf->SetFont('Arial', '', 8.2);
$pdf->Cell(71, 5, utf8_decode(" _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "), 0, 1, 'C');

// Variable para almacenar el total de los subtotales
$total = 0;

// Iterar sobre los datos de ventas
while ($row = mysqli_fetch_assoc($ventas)) {


   

    // Contenido de las filas
    $pdf->SetFont('Arial', '', 6.8);
    $pdf->Cell(17, 5, $row['codigo'], 0, 0, 'L');
    $pdf->Cell(5, 5, $row['cantidad'], 0, 0, 'L');
    $pdf->Cell(65, 5, $row['descripcion'], 0, 0, 'L'); //$pdf->Cell(25, 5, $row['descripcion'], 0, 0, 'L');  
    $pdf->Cell(-27, 5, $row['precio'], 0, 0, 'L');    //$pdf->Cell(12, 5, $row['precio'], 0, 0, 'L'); 
    $subtotal = $row['cantidad'] * $row['precio'];
    $total += $subtotal; 
    $pdf->Cell(0, 5, number_format($subtotal, 2, '.', ','), 0, 1, 'L');
}


// Mostrar el total y establecer subtotal y descuento a 0
$pdf->Cell(38, 5, '', 0, 0, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(20, 5, 'Sub Total     : ', 0, 0, 'L');
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(40, 5, number_format($total, 2, '.', ','), 0, 1, 'L'); 

// Espacio en blanco para mover el texto hacia la derecha
$pdf->Cell(38.1, 2, '', 0, 0, 'L');
$pdf->SetFont('Arial', '', 8); 
$pdf->Cell(20, 2, 'Descuento   : ', 0, 0, 'L');
$pdf->SetFont('Arial', 'B', 8); 
$pdf->Cell(1.5, 2, '', 0, 0, 'L');
$pdf->Cell(20, 2, '0.00', 0, 1, 'L'); 

// Espacio en blanco para mover el texto hacia la derecha
$pdf->Cell(38, 6, '', 0, 0, 'L');
$pdf->SetFont('Arial', '', 8); 
$pdf->Cell(16, 6, 'Total', 0, 0, 'L');
$pdf->Cell(4, 6, ': ', 0, 0, 'L');
$pdf->SetFont('Arial', 'B', 8); 
$pdf->Cell(40, 6, number_format($total, 2, '.', ','), 0, 1, 'L');


// Convertir el total a texto
$totalEnTexto = numeroATexto($total);

// Concatenar "soles" al texto
$totalEnTexto .= " con 00/100 soles";

// Mostrar el total en texto
$pdf->SetFont('Arial', '', 8); 
$pdf->Cell(60, 6, utf8_decode('Son: ' . $totalEnTexto), 0, 1, 'L');




//Email
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(70, 8, utf8_decode($datos['email']), 0, 1, 'C');

//Consulta de venta
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(70, -1, utf8_decode("Consulte su boleta de venta electrónica en"), 0, 1, 'C');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(70, 7, utf8_decode($datos['link']), 0, 2, 'C');

//Salida del PDF
$pdf->Output("ventas.pdf", "I");
?>