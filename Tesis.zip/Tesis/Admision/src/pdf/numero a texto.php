<?php
function numeroATexto($numero)
{
    $cadenas = array(
        0 => 'cero',
        1 => 'uno',
        2 => 'dos',
        3 => 'tres',
        4 => 'cuatro',
        5 => 'cinco',
        6 => 'seis',
        7 => 'siete',
        8 => 'ocho',
        9 => 'nueve',
        10 => 'diez',
        11 => 'once',
        12 => 'doce',
        13 => 'trece',
        14 => 'catorce',
        15 => 'quince',
        16 => 'dieciséis',
        17 => 'diecisiete',
        18 => 'dieciocho',
        19 => 'diecinueve',
        20 => 'veinte',
        30 => 'treinta',
        40 => 'cuarenta',
        50 => 'cincuenta',
        60 => 'sesenta',
        70 => 'setenta',
        80 => 'ochenta',
        90 => 'noventa',
        100 => 'cien',
        200 => 'doscientos',
        300 => 'trescientos',
        400 => 'cuatrocientos',
        500 => 'quinientos',
        600 => 'seiscientos',
        700 => 'setecientos',
        800 => 'ochocientos',
        900 => 'novecientos'
    );

    if ($numero < 21) {
        return $cadenas[$numero];
    }

    if ($numero < 100) {
        $decenas = floor($numero / 10) * 10;
        $unidades = $numero % 10;
        return $cadenas[$decenas] . (($unidades > 0) ? ' y ' . $cadenas[$unidades] : '');
    }

    if ($numero < 1000) {
        $centenas = floor($numero / 100) * 100;
        $resto = $numero - $centenas;
        return $cadenas[$centenas] . (($resto > 0) ? ' ' . numeroATexto($resto) : '');
    }

    return '';
}
?>