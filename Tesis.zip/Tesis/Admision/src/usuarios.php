<?php include_once "includes/header.php";
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "usuarios";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['nombre']) || empty($_POST['correo']) || empty($_POST['usuario']) || empty($_POST['clave'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
        $nombre = $_POST['nombre'];
        $email = $_POST['correo'];
        $user = $_POST['usuario'];
        $clave = md5($_POST['clave']);
        $query = mysqli_query($conexion, "SELECT * FROM usuario where correo = '$email'");
        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El correo ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO usuario(nombre,correo,usuario,clave) values ('$nombre', '$email', '$user', '$clave')");
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            Usuario registrado
                        </div>';
                echo '<meta http-equiv="refresh" content="0">';
                exit();
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar
                    </div>';
                echo '<meta http-equiv="refresh" content="0">';
                exit();
            }
        }
    }
}
?>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_usuario"><i
        class="fas fa-plus"></i></button>
<div id="nuevo_usuario" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="my-modal-title">Nuevo Usuario</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <?php echo isset($alert) ? $alert : ''; ?>
                    <div class="form-group">
                        <label for="nombre"><i class="fas fa-user"></i> Nombre Completo</label>
                        <input type="text" class="form-control" placeholder="Ejemplo: María García Pérez" name="nombre"
                            id="nombre" required>
                    </div>
                    <div class="form-group">
                        <label for="usuario"><i class="fas fa-briefcase"></i> Cargo</label>
                        <input type="text" class="form-control" placeholder="Ejemplo: Administrativo/a" name="usuario"
                            id="usuario" required>
                    </div>
                    <div class="form-group">
                        <label for="correo"><i class="fas fa-envelope"></i> Correo</label>
                        <input type="email" class="form-control" placeholder="Ejemplo: correo@ejemplo.com" name="correo"
                            id="correo" required>
                    </div>
                    <div class="form-group">
                        <label for="clave"><i class="fas fa-lock"></i> Contraseña</label>
                        <div class="ResetPassword">

                            <input type="password" class="form-control" placeholder="Ingresar Contraseña Actual"
                                name="clave" id="clave" required>
                            <img class="eyes" id="eyes4" src="../assets/img/eyes/invisible.png"
                                alt="Mostrar contraseña">

                        </div>
                    </div>
                    <input type="submit" value="Registrar" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
        <thead class="thead-dark">
            <tr>
                <th><i class="fas fa-id-badge"></i> ID</th>
                <th><i class="fas fa-user"></i> Nombre Completo</th>
                <th><i class="fas fa-briefcase"></i> Cargo</th>
                <th><i class="fas fa-envelope"></i> Correo</th>
                <th><i class="fas fa-lock"></i> Contraseña</th>
                <th><i class="fas fa-toggle-on"></i> Estado</th>
                <th><i class="fas fa-cogs"></i> Acciones</th>

            </tr>
        </thead>
        <tbody>
            <?php ?>
            <?php
            include "../conexion.php";

            $query = mysqli_query($conexion, "SELECT * FROM usuario ORDER BY estado DESC");
            $result = mysqli_num_rows($query);
            if ($result > 0) {
                while ($data = mysqli_fetch_assoc($query)) {
                    if ($data['estado'] == 1) {
                        $estado = '<span class="badge badge-pill badge-success">Activo</span>';
                    } else {
                        $estado = '<span class="badge badge-pill badge-danger">Inactivo</span>';
                    }
                    ?>
                    <tr>

                        <td>
                            <?php echo $data['idusuario']; ?>
                        </td>
                        <td>
                            <?php echo $data['nombre']; ?>
                        </td>
                        <td>
                            <?php echo $data['usuario']; ?>
                        </td>
                        <td>
                            <?php echo $data['correo']; ?>
                        </td>
                        <td>
                            <?php echo $data['clave']; ?>
                        </td>
                        <td>
                            <?php echo $estado; ?>
                        </td>
                        <td>
                            <?php if ($data['estado'] == 1) { ?>
                                <a href="rol.php?id=<?php echo $data['idusuario']; ?>" class="btn btn-warning"><i
                                        class='fas fa-key'></i></a>
                                <a href="editar_usuario.php?id=<?php echo $data['idusuario']; ?>" class="btn btn-success"><i
                                        class='fas fa-edit'></i></a>
                                <form action="eliminar_usuario.php?id=<?php echo $data['idusuario']; ?>" method="post"
                                    class="confirmar d-inline">
                                    <button class="btn btn-danger" type="submit"><i class='fas fa-trash-alt'></i> </button>
                                </form>

                            <?php } ?>

                            <?php if ($data['estado'] == 0) { ?>
                                <a href="activar_usaurio.php?id=<?php echo $data['idusuario']; ?>" class="btn btn-warning"><i
                                        class='fas fa-lock'></i></a>


                                <form action="☺elimar_permanente_usaurio.php?id=<?php echo $data['idusuario']; ?>" method="post"
                                    class="confirmarPermanente d-inline">
                                    <button class="btn btn-dark" type="submit"><i class='fas fa-skull'></i> </button>
                                </form>
                            <?php }
                            ?>

                        </td>
                    </tr>
                <?php }
            } ?>
        </tbody>
    </table>
</div>
<?php include_once "includes/footer.php"; ?>