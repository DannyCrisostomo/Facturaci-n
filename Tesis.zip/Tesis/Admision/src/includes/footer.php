</div>
</main>
<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Admision&copy; Historias Clinicas 2024</div>
            <div>
                <a class="text-muted" href="#">Privacidad y Politica</a>
                &middot;
                <a class="text-muted" href="#">Terminos &amp; Condiciones</a>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<div id="nuevo_pass" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Cambiar contraseña</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="frmPass">


                    <div class="form-group">
                        <?php echo $_SESSION['nombre']; ?>
                    </div>



                    <div class="form-group">
                        <label for="actual"><i class="fas fa-key"></i> Contraseña Actual</label>

                        <div class="ResetPassword">
                            <input id="actual" class="form-control" type="password" name="actual"
                                placeholder="Contraseña actual" required>
                            <img class="eyes" id="eyes1" src="../assets/img/eyes/invisible.png" alt="Mostrar contraseña">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="nueva"><i class="fas fa-key"></i> Nueva Contraseña</label>

                        <div class="ResetPassword">
                            <input id="nueva" class="form-control" type="password" name="nueva"
                                placeholder="Nueva contraseña" required>
                            <img class="eyes" id="eyes2" src="../assets/img/eyes/invisible.png" alt="Mostrar contraseña">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="confirmar"><i class="fas fa-key"></i> Confirmar Nueva Contraseña</label>

                        <div class="ResetPassword">

                            <input id="confirmar" class="form-control" type="password" name="confirmar"
                                placeholder="Confirmar nueva contraseña" required>
                            <img class="eyes" id="eyes3" src="../assets/img/eyes/invisible.png" alt="Mostrar contraseña">
                        </div>
                    </div>
                    <button class="btn btn-primary" type="button" onclick="btnCambiar(event)">Cambiar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="../assets/js/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script src="../assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="../assets/js/scripts.js"></script>
<script src="../assets/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
<script src="../assets/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/jquery-ui/jquery-ui.min.js"></script>
<script src="../assets/js/Chart.bundle.min.js"></script>
<script src="../assets/js/funciones.js"></script>
</body>

</html>