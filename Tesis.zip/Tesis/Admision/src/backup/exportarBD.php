<?php
function exportarBaseDeDatos($host, $usuario, $contraseña, $nombre_base_datos) {
    // Crear la conexión a la base de datos
    $conexion = new mysqli($host, $usuario, $contraseña, $nombre_base_datos);

    // Verificar si hay errores de conexión
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Nombre del archivo de respaldo
    $nombre_archivo_respaldo = 'AdmisionBD.sql';

    // Ruta completa del archivo de respaldo
    $ruta_archivo_respaldo = sys_get_temp_dir() . '/' . $nombre_archivo_respaldo;

    // Abrir el archivo de respaldo para escritura
    $fp = fopen($ruta_archivo_respaldo, 'w');

    // Verificar si se pudo abrir el archivo de respaldo
    if ($fp === false) {
        die("No se pudo abrir el archivo de respaldo para escritura.");
    }

    // Obtener el nombre de todas las tablas de la base de datos
    $tablas = $conexion->query("SHOW TABLES");

    // Iterar sobre todas las tablas para obtener sus estructuras y datos
    while ($tabla = $tablas->fetch_row()) {
        $nombre_tabla = $tabla[0];

        // Obtener la estructura de la tabla y escribirla en el archivo de respaldo
        $estructura_tabla = $conexion->query("SHOW CREATE TABLE $nombre_tabla");
        $fila_estructura = $estructura_tabla->fetch_row();
        fwrite($fp, "\n\n" . $fila_estructura[1] . ";\n\n");

        // Obtener los datos de la tabla y escribirlos en el archivo de respaldo
        $datos_tabla = $conexion->query("SELECT * FROM $nombre_tabla");
        while ($fila = $datos_tabla->fetch_assoc()) {
            $valores = array_map(array($conexion, 'real_escape_string'), array_values($fila));
            $columnas = implode("', '", $valores);
            fwrite($fp, "INSERT INTO $nombre_tabla VALUES ('$columnas');\n");
        }
    }

    // Cerrar el archivo de respaldo y liberar los recursos
    fclose($fp);
    $conexion->close();

    // Devolver la ruta del archivo de respaldo
    return $ruta_archivo_respaldo;
}

// Llamar a la función para exportar la base de datos
$host = "localhost";
$usuario = "root";
$contraseña = "";
$nombre_base_datos = "admision";

$ruta_archivo = exportarBaseDeDatos($host, $usuario, $contraseña, $nombre_base_datos);

// Descargar el archivo de respaldo
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($ruta_archivo) . '"');
header('Content-Length: ' . filesize($ruta_archivo));
readfile($ruta_archivo);

// Eliminar el archivo de respaldo temporal después de descargarlo
unlink($ruta_archivo);
?>
