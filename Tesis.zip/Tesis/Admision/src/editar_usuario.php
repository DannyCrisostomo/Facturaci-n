<?php 
include_once "includes/header.php";
require "../conexion.php";

$id_user = $_SESSION['idUser'];
$permiso = "usuarios";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);

if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['nombre']) || empty($_POST['correo']) || empty($_POST['usuario']) || empty($_POST['clave'])) {
        $alert = '<div class="alert alert-danger" role="alert">Todos los campos son requeridos</div>';
    } else {
        $idusuario = $_GET['id'];
        $nombre = $_POST['nombre'];
        $correo = $_POST['correo'];
        $usuario = $_POST['usuario'];
        $clave_actual = md5($_POST['clave']);
        
        // Verificar si la contraseña actual es correcta
        $sql_verify_password = mysqli_query($conexion, "SELECT clave FROM usuario WHERE idusuario = $idusuario");
        $row = mysqli_fetch_assoc($sql_verify_password);
        $clave_guardada = $row['clave'];
        
        if ($clave_actual == $clave_guardada) {
            // La contraseña actual coincide, proceder con la actualización de datos
            $clave = $clave_guardada; // No necesitamos actualizar la contraseña en este caso
            $sql_update = mysqli_query($conexion, "UPDATE usuario SET nombre = '$nombre', correo = '$correo', usuario = '$usuario' WHERE idusuario = $idusuario");
            if ($sql_update) {
                $alert = '<div class="alert alert-success" role="alert">Usuario Actualizado</div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">Error al actualizar el usuario</div>';
            }
        } else {
            // La contraseña actual no coincide
            $alert = '<div class="alert alert-danger" role="alert">La contraseña actual es incorrecta</div>';
        }
    }
}

// Mostrar Datos
if (empty($_REQUEST['id'])) {
    header("Location: usuarios.php");
}

$idusuario = $_REQUEST['id'];
$sql = mysqli_query($conexion, "SELECT * FROM usuario WHERE idusuario = $idusuario");
$result_sql = mysqli_num_rows($sql);

if ($result_sql == 0) {
    header("Location: usuarios.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $idcliente = $data['idusuario'];
        $nombre = $data['nombre'];
        $correo = $data['correo'];
        $usuario = $data['usuario'];
        // No necesitamos almacenar la contraseña en esta variable
    }
}
?>
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header bg-primary text-white">
                Modificar Usuario
            </div>
            <div class="card-body">
                <form class="" action="" method="post">
                    <?php echo isset($alert) ? $alert : ''; ?>
                    <input type="hidden" name="id" value="<?php echo $idusuario; ?>">
                    <div class="form-group">
                        <label for="nombre">Nombre Completo</label>
                        <input type="text" placeholder="Actualizar Nombre Completo" class="form-control" name="nombre" id="nombre" value="<?php echo $nombre; ?>">
                    </div>

                    <div class="form-group">
                        <label for="usuario">Cargo</label>
                        <input type="text" placeholder="Actualizar Cargo" class="form-control" name="usuario" id="usuario" value="<?php echo $usuario; ?>">
                    </div>

                    <div class="form-group">
                        <label for="correo">Correo</label>
                        <input type="text" placeholder="Actualizar Correo" class="form-control" name="correo" id="correo" value="<?php echo $correo; ?>">
                    </div>

                    <div class="form-group">
                        <label for="clave">Contraseña Actual</label>
                        
                    <div class="ResetPassword">

                        <input type="password" class="form-control" placeholder="Ingresar Contraseña Actual" name="clave" id="clave" required>
                        <img class="eyes" id="eyes4" src="../assets/img/eyes/invisible.png" alt="Mostrar contraseña">
                  
                    </div>
                    </div>





                    <button type="submit" class="btn btn-primary"><i class="fas fa-user-edit"></i></button>
                    <a href="usuarios.php" class="btn btn-danger">Atrás</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once "includes/footer.php"; ?>
