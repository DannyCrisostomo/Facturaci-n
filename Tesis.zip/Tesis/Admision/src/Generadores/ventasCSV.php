<?php
require_once "./../../conexion.php";

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Paso 1: Obtener los valores de las fechas del formulario
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];

    // Paso 2: Construir la consulta SQL
    $sql = "SELECT * FROM ventas WHERE fecha BETWEEN '$fecha_inicio' AND '$fecha_fin'";

    // Paso 3: Ejecutar la consulta SQL
    $resultado = mysqli_query($conexion, $sql);

    // Generar el archivo CSV temporalmente
    $archivo_csv_temporal = 'ventas_reporte.csv';
    $delimiter = ';'; // Cambiado el delimitador a punto y coma
    $fp = fopen($archivo_csv_temporal, 'w');

    // Agregar metadatos para ajustar el ancho de las columnas y filas en Excel
    fwrite($fp, "sep=" . $delimiter . PHP_EOL);

    // Encabezados del archivo CSV
    $encabezados = array('id', 'id_cliente', 'codigo_venta', 'fecha', 'total', 'id_usuario');
    fputcsv($fp, $encabezados, $delimiter);

    // Calcular el ancho máximo de cada columna
    $ancho_columnas = array_fill(0, count($encabezados), 0);
    while ($fila = mysqli_fetch_assoc($resultado)) {
        // Escribir datos de la consulta al archivo CSV
        fputcsv($fp, $fila, $delimiter);
        
        // Actualizar el ancho máximo de cada columna
        foreach ($encabezados as $indice => $columna) {
            $longitud = mb_strlen($fila[$columna], 'UTF-8');
            if ($longitud > $ancho_columnas[$indice]) {
                $ancho_columnas[$indice] = $longitud;
            }
        }
    }

    // Cerrar el archivo CSV
    fclose($fp);

    // Descargar el archivo CSV generado
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($archivo_csv_temporal) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($archivo_csv_temporal));
    readfile($archivo_csv_temporal);

    // Eliminar el archivo temporal después de descargarlo
    unlink($archivo_csv_temporal);
    exit;
}
?>
