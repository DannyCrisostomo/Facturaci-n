<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error 404 - Página no encontrada</title>
    <style>
        * {
            margin: 0;
        }
        body {
            height: 100vh;
        }
        img {
            max-width: 100%;
            height: 100%;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <img src="./../assets/img/svg/404 Error Page not Found with people connecting a plug-pana (1).svg" alt="">
</body>

</html>